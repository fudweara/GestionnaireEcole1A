create trigger LIEU_ON_INSERT
  before insert
  on LIEU
  for each row
  BEGIN
  SELECT lieu_seq.nextval
  INTO :new.idLieu
  FROM dual;
END;
/

