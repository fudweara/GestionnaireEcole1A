create trigger CARTELEO_ON_INSERT
  before insert
  on CARTELEO
  for each row
  BEGIN
  SELECT carteLeo_seq.nextval
  INTO :new.idBadge
  FROM dual;
END;
/

