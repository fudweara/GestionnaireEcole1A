create trigger TYPEACCES_ON_INSERT
  before insert
  on TYPEACCES
  for each row
  BEGIN
  SELECT typeAcces_seq.nextval
  INTO :new.idTypeAcces
  FROM dual;
END;
/

