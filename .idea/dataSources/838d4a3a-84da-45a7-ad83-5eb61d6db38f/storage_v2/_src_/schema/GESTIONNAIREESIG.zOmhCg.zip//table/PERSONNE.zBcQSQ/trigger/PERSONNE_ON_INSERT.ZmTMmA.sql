create trigger PERSONNE_ON_INSERT
  before insert
  on PERSONNE
  for each row
  BEGIN
  SELECT personne_seq.nextval
  INTO :new.idPersonne
  FROM dual;
END;
/

