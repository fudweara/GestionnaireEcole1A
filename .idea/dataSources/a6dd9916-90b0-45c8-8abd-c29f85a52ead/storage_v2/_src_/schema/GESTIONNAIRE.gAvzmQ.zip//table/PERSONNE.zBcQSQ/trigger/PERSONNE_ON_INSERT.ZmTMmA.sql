create trigger PERSONNE_ON_INSERT
  before insert
  on PERSONNE
  for each row
  BEGIN
  SELECT PERSONNE_SEQ.NEXTVAL
  INTO :new.idPersonne
  FROM dual;
END;
/

